<script langauge="javascript">
checkconfirmclosewindow();
function checkconfirmclosewindow()
{
 
window.close();

}
</script>